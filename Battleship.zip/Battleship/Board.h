//
//  Board.h
//  Battleship
//

#ifndef BOARD_H
#define BOARD_H

#include <iostream>

class Board
{
    
    
};

#endif
