#include "RandomNumberGuesser.h"
#include <cstdlib>
#include <time.h>
#include <iostream>
using namespace std;

RandomNumberGuesser::RandomNumberGuesser(int l,int h):NumberGuesser(l,h)
{ 
  current=0;
  count=0;
}

int RandomNumberGuesser::getCurrentGuess()
{
  srand(time(NULL));
  if(count==0)
    current=(rand() % (high-low+1))+low;
  count++;
  return current;  
}

void RandomNumberGuesser::higher()
{
  int tmp=low;
  low=getCurrentGuess()+1;
  count=0;
  if (low>high)
  {
  	low=tmp;
  	count=1;
  	cout<<"higher() shouldn't be called, going beyond scope"<<endl;
  }
}

void RandomNumberGuesser::lower()
{
  int tmp=high;
  high=getCurrentGuess()-1;
  count=0;
  if (low>high)
  {
  	high=tmp;
  	count=1;
  	cout<<"lower() shouldn't be called, going beyond scope"<<endl;
  }

}

void RandomNumberGuesser::reset()
{
  low=originalLow;
  high=originalHigh;
}
