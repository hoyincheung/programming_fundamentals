#include "NumberGuesser2.h"
#ifndef RANDOMNUMBERGUESSER_H
#define RANDOMNUMBERGUESSER_H

class RandomNumberGuesser: public NumberGuesser
{
  private:
    int current;
    int count;
  public:
    RandomNumberGuesser(int, int);
    int getCurrentGuess();
    void higher();
    void lower();
    void reset();
};

#endif
       
