#ifndef NUMBERGUESSER_H
#define NUMBERGUESSER_H

class NumberGuesser
{
  private:
    int upperEnd;
    int lowerEnd;
    int midpoint;
    int temLower;
    int temUpper;
  public:
    NumberGuesser();
    NumberGuesser(int, int);
    void higher();
    void lower();
    int getCurrentGuesser();
    void reset();
};

#endif
