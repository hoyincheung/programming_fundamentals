#include "NumberGuesser.h"
#include <iostream>
using namespace std;

NumberGuesser::NumberGuesser()
{
  cout<<"\nIn the default constructor!";
}

NumberGuesser::NumberGuesser(int lowerBound, int upperBound)
{
  lowerEnd=lowerBound;
  temLower=lowerBound;
  upperEnd=upperBound;
  temUpper=upperBound;
}

//returns the midpoint of the possible values 
int NumberGuesser::getCurrentGuesser()
{
  midpoint=(lowerEnd+upperEnd)/2;

  return midpoint;
}

//adjust the state to represent a higher possible range of values
void NumberGuesser::higher()
{
  lowerEnd=midpoint+1;
}

//adjust the state to represent a lower possible range of values
void NumberGuesser::lower()
{
  upperEnd=midpoint-1;
}

//resets lowerBound and upperBound to their original values
void NumberGuesser::reset()
{
  lowerEnd=temLower;
  upperEnd=temUpper;
}