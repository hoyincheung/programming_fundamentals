//Assignment 10 Haoran Zhang
//This program guess a number the user chosen between 1 and 100
#include <iostream>
using namespace std;

int main()
{
  NumberGuesser littleGuesser(1,100);
  char response;
  char chioce;

  cout<<"\nThink of a number between 1 and 100";

  do
  {
    do
    {
      cout<<"\nIs the number "<<littleGuesser.getCurrentGuesser()<<"? (h/l/c):";
      cin>>response;
      if(response=='h')
        littleGuesser.higher();
      else if(response=='l')
        littleGuesser.lower();
      else 
        cout<<"\nYou picked "<<littleGuesser.getCurrentGuesser()<<"? Great pick.";
    }while(response!='c');

    cout<<"\nDo you want to play again? (y/n):";
    cin>>chioce;

    if(chioce=='y')
      littleGuesser.reset();
    else
      cout<<"\nGoodbye!";
  }while(chioce=='y'); 

  return 0;
}
[hzhan144@hills ~]$ ./a.out
/*SAMPLE OUTPUT
Think of a number between 1 and 100
Is the number 50? (h/l/c):h

Is the number 75? (h/l/c):h

Is the number 88? (h/l/c):l

Is the number 81? (h/l/c):c

You picked 81? Great pick.
Do you want to play again? (y/n):y

Is the number 50? (h/l/c):l

Is the number 25? (h/l/c):h

Is the number 37? (h/l/c):c

You picked 37? Great pick.
Do you want to play again? (y/n):n

Goodbye! 
*/