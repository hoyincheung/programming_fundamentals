#include <iostream>
#include "circle.h"
using namespace std;

int main()
{
  Circle myCircle;
  Circle *ptr;

  myCircle.setRadius(3.0);
  myCircle.setX(4.0);
  myCircle.setY(5.0);
  cout<<"\nArea of my circle is: "<<myCircle.getArea()<<endl;

  ptr=&myCircle;
  ptr->setRadius(2.0);
  ptr->setX(2.0);
  ptr->setY(3.0);
  if(ptr->containsPoint(2.0,4.0))
    cout<<"\nPiont 1 is contained in my circle."<<endl;
  else
    cout<<"\nPiont 1 is not contained in my circle."<<endl;

  if(ptr->containsPoint(2.0,10.0))
    cout<<"\nPoint 2 is contained in my circle."<<endl;
  else
    cout<<"\nPoint 2 is not contained in my circle."<<endl;

  return 0;
}

     
