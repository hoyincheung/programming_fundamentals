#ifndef CIRCLE_H
#define CIRCLE_H

class Circle
{
  private:
    double x;
    double y;
    double radius;
  public:
    void setRadius(double);
    void setX(double);
    void setY(double);
    double getRadius();
    double getX();
    double getY();
    double getArea();
    bool containsPoint(double, double);
};

#endif
