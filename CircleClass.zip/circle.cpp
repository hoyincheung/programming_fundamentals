#include "circle.h"
#include <cmath>

void Circle::setRadius(double r)
{
  radius=r;
}

void Circle::setX(double xValue)
{
  x=xValue;
}

void Circle::setY(double yValue)
{
  y=yValue;
}

double Circle::getRadius()
{
  return radius;
}

double Circle::getX()
{
  return x;
}

double Circle::getY()
{
  return y;
}

double Circle::getArea()
{
  return radius*radius*3.14;
}

/*this function retuens true if the point is contained 
  in the circle, and false if not*/
bool Circle::containsPoint(double xCoordinate, double yCoordinate)
{
  double distance;
  
  //calculates the distance from a point to the center of the circle
  distance=sqrt((xCoordinate-x)*(xCoordinate-x) + (yCoordinate-y)*(yCoordinate-y));

  if(distance<=radius)
    return true;
  else
    return false;
}
