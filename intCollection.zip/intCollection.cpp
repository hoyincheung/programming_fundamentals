#include "intCollection.h"
#include <iostream>
using namespace std;

IntCollection::IntCollection()
{
  //initialize member data to reflect an empty IntCollection
  size = capacity = 0;
  data = NULL;
}

IntCollection& IntCollection::operator=(const IntCollection &c)
{
  size=c.size;
  capacity=c.capacity;
  data=new int[capacity];
  for(int i=0; i<size; i++)
    data[i]=c.data[i];

  return *this;
}

IntCollection::IntCollection(const IntCollection &c)
{
  size=c.size;
  capacity=c.capacity;
  for(int i=0; i<size; i++)
    data[i]=c.data[i];
}

void IntCollection::addCapacity()
{
  //create a new, bigger buffer, copy the current data to it, delete
  //the old buffer, and point our data pointer to the new buffer
  int *newData;
  capacity += CHUNK_SIZE;
  newData = new int[capacity];
  for (int i=0; i<size; i++)
    newData[i] = data[i];
  delete [] data;
  data = newData;
}

void IntCollection::add(int value)
{
  //first, allocate more memory if we need to
  if (size == capacity)
    addCapacity();

  //now, add the data to our array and increment size
  data[size++] = value;
}
int IntCollection::get(int index)
{
  if (index<0 || index>=size)
  {
    cout << "ERROR: get() trying to access index out of range.\n";
    exit(1);
  }

  return data[index];
}

int IntCollection::getSize()
{
  return size;
}

bool IntCollection::operator==(const IntCollection &c)
{
  if(c.size!=size)
        return false;
  for (int i=0;i<size;i++)
  {
   	if(c.data[i]!=data[i])
      return false;
  }
  return true;
}IntCollection& IntCollection::operator<<(int value)
{
  if(size==capacity)
    addCapacity();
  data[size++]=value;

  return *this;
}

IntCollection::~IntCollection()
{
  delete [] data;
}