//CS 110B Haoran Zhang
//Assignment 11

#include "intCollection.h"
#include <iostream>
using namespace std;

int main()
{
  IntCollection c;

  c.add(45);
  c.add(-210);
  c.add(77);
  c.add(2);
  c.add(-21);
  c.add(42);
  c.add(7);

  for (int i = 0; i < c.getSize(); i++)
  {
    cout << c.get(i) << endl;
  }

  IntCollection d;

  d=c;

  cout<<"\nsize of d: "<<d.getSize();
  for(int i=0; i<d.getSize();i++)
    cout<<"\n"<<i+1<<"element in array d "<<d.get(i);

  IntCollection e,f;

  f=e=c;
  cout<<"\nsize of f: "<<f.getSize();
  for(int i=0; i<f.getSize();i++)
    cout<<"\n"<<i+1<<"element in array f "<<f.get(i);

  if(f==c)
    cout<<"\nsize and values of f and c are the same.";

  c<<45<<-210;
  for(int i=0; i<c.getSize();i++)
    cout<<"\n"<<i+1<<"element in array c "<<c.get(i);

  //c.addCapacity();

  return 0;
}

/*Sample Output
45
-210
77
2
-21
42
7

size of d: 7
1element in array d 45
2element in array d -210
3element in array d 77
4element in array d 2
5element in array d -21
6element in array d 42
7element in array d 7
size of f: 7
1element in array f 45
2element in array f -210
3element in array f 77
4element in array f 2
5element in array f -21
6element in array f 42
7element in array f 7
size and values of f and c are the same.
1element in array c 45
2element in array c -210
3element in array c 77
4element in array c 2
5element in array c -21
6element in array c 42
7element in array c 7
8element in array c 45
*/
/*if put c.addCapacity() in main, the program has compiling  error,
  error message indicates that private function is used shown */